
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Book } from '../model/book.model';
import { CONFIG } from '../constants/constants';


@Injectable({
  providedIn: 'root'
})
export class BookService { 

  constructor(private http:HttpClient) { }

  getBookByAuthorName (authorName: string): Observable<Book> {
    return this.http.get<Book>(CONFIG.REST_END_POINT+'byAuthorName/'+authorName)
  }

  getBookByTitle (title: string): Observable<Book> {
    return this.http.get<Book>(CONFIG.REST_END_POINT+'byTitle/'+title);
  }


}