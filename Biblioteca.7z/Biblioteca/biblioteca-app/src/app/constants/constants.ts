export var CONFIG = {    
    REST_END_POINT : "http://localhost:8070/books/"
}