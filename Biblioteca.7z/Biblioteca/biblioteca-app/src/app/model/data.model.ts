export class Data {
    constructor(
        public idBook:number,
        public title:string,
        public isbs:string,
        public year:number,
        public createAt:string,
        public modifiedAt:string,
        public nameAuthor:string
    ){ }
}