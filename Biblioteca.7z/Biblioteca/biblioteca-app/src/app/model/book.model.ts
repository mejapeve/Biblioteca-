import { Data } from "./data.model";

export class Book {

    constructor(
        public responseCode : string, 
        public responseMessage: string, 
        public data: Data[]
    ){}
    
}



