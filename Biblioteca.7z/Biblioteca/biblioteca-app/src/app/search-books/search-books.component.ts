import { Component, OnInit } from '@angular/core';
import { Book } from '../model/book.model';
import { BookService } from '../services/book.service';
import { Data } from '../model/data.model';

declare var $: any;

@Component({
  selector: 'app-search-books',
  templateUrl: './search-books.component.html',
  styleUrls: ['./search-books.component.css']
})


export class SearchBooksComponent implements OnInit {

  searByAuthor!: string;

  searByTitulo!: string;

  data!: Data[];

  books!: any;

  


  constructor(private bookService: BookService) { }

  ngOnInit(): void {
  }

  searchByAuthor() {
    this.bookService.getBookByAuthorName(this.searByAuthor)
      .subscribe(
        (books: Book) => {
          this.books = books.data;          
        }
      ); 
      $("#searByAuthor").val("")    
  }

  searchByTitulo() {
    this.bookService.getBookByTitle(this.searByTitulo)
      .subscribe(
        (books: Book) => {
          this.books = books.data;                 
        }
      );
      $("#searByTitulo").val("")  
  }  
}