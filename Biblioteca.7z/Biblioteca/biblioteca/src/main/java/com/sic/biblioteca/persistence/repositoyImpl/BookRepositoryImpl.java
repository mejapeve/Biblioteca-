package com.sic.biblioteca.persistence.repositoyImpl;

import com.sic.biblioteca.domain.entity.AuthorDomain;
import com.sic.biblioteca.domain.entity.BookDomain;
import com.sic.biblioteca.domain.repository.BookRepositoryDomain;
import com.sic.biblioteca.persistence.entity.Book;
import com.sic.biblioteca.persistence.mapper.BookMapper;
import com.sic.biblioteca.persistence.repositoyJpa.AuthorRepositoryJpa;
import com.sic.biblioteca.persistence.repositoyJpa.BookRepositoryJpa;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BookRepositoryImpl implements BookRepositoryDomain {
    @Autowired
    BookRepositoryJpa bookRepositoryJpa;
    @Autowired
    AuthorRepositoryJpa authorRepositoryJpa;
    @Autowired
    BookMapper bookMapper;

    @Override
    public Book createBook(BookDomain bookDomain) {
        return bookRepositoryJpa.saveAndFlush(bookMapper.bookDomainTobook(bookDomain));
    }

    @Override
    public Optional<BookDomain> findBookByIsbn(String isbn) {
         Optional<Book> bookDomain = bookRepositoryJpa.findByIsbn(isbn);
        if (bookDomain.isPresent()){
            return Optional.of(bookMapper.bookToBookDomain(bookDomain.get()));
        }else{
            return Optional.empty();
        }
    }

    @Override
    public List<BookDomain> findByAuthorName(String authorName) {
        List<Book> bookList = bookRepositoryJpa.findByAuthorName(authorName);
        if (!bookList.isEmpty()){
            return bookMapper.bookListToBookDomainList(bookList);
        }
        return new ArrayList<>();
    }

    @Override
    public List<BookDomain> findByTitle(String title) {
        List<Book> bookList = bookRepositoryJpa.findByTitle(title);
        if (!bookList.isEmpty()){
            return bookMapper.bookListToBookDomainList(bookList);
        }
        return new ArrayList<>();
    }


}
