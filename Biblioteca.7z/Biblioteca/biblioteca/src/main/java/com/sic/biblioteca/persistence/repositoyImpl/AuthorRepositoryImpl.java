package com.sic.biblioteca.persistence.repositoyImpl;


import com.sic.biblioteca.app.exceptions.AuthorDoesNotExist;
import com.sic.biblioteca.domain.entity.AuthorDomain;
import com.sic.biblioteca.persistence.entity.Author;
import com.sic.biblioteca.persistence.repositoyJpa.AuthorRepositoryJpa;
import com.sic.biblioteca.domain.repository.AuthorRepositoryDomain;
import com.sic.biblioteca.persistence.mapper.AuthorMapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;


public class AuthorRepositoryImpl implements AuthorRepositoryDomain {
    @Autowired
    AuthorRepositoryJpa authorRepositoryJpa;
    @Autowired
    AuthorMapper authorMapper;

    @Override
    public Author creteAuthor(AuthorDomain authorDomain) {
        return authorRepositoryJpa.saveAndFlush(authorMapper.authorDomainToAuthor(authorDomain));
    }

    @Override
    public Optional<AuthorDomain> findByEmail(String email) {
        Optional<Author> authorDomain = authorRepositoryJpa.findByEmail(email);
        if (authorDomain.isPresent()){
            return Optional.of(authorMapper.authorToAuthorDomain(authorDomain.get()));
        }else{
            return Optional.empty();
        }
    }

    @Override
    public Optional<AuthorDomain> findAuthorById(long id) {
        Optional<Author>  authorDomain = authorRepositoryJpa.findById(id);
        if (authorDomain.isPresent()){
            return Optional.of(authorMapper.authorToAuthorDomain(authorDomain.get()));
        }else{
            return Optional.empty();
        }

    }

    @Override
    public List<AuthorDomain> findByName(String authorName) {
       List<Author> authorList = authorRepositoryJpa.findByName(authorName);
       if(!authorList.isEmpty()){
           return authorMapper.authorListToAuthorDomainList(authorList);
       }else{
           throw new AuthorDoesNotExist("The author " + authorName + " does not exist");
       }
    }


}
