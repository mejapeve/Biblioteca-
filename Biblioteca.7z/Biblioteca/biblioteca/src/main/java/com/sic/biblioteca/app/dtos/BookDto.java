package com.sic.biblioteca.app.dtos;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDateTime;


@Data
public class BookDto {
    @NotNull
    private long id;
    @NotNull
    private long authorId;
    @NotNull
    private String title;
    @NotNull
    private String isbn;
    @NotNull
    private int year;
    @NotNull
    private LocalDateTime created_at;
    @NotNull
    private LocalDateTime modified_at;
    @NotNull
    private AuthorDto authorDto;
}
