package com.sic.biblioteca.persistence.mapper;


import com.sic.biblioteca.domain.entity.AuthorDomain;
import com.sic.biblioteca.persistence.entity.Author;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AuthorMapper {
    Author authorDomainToAuthor(AuthorDomain authorDomain);
    AuthorDomain authorToAuthorDomain(Author author);
    List<AuthorDomain> authorListToAuthorDomainList(List<Author> authorList);






}
