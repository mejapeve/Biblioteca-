package com.sic.biblioteca.app.service;

import com.sic.biblioteca.app.dtos.BookDto;
import com.sic.biblioteca.app.dtos.request.CreateBookRequestDto;
import com.sic.biblioteca.app.dtos.request.GetBookByAuthorNameRequestDto;
import com.sic.biblioteca.app.dtos.request.GetBookByTitleRequestDto;
import com.sic.biblioteca.app.dtos.response.CreateBookResponseDto;
import com.sic.biblioteca.app.dtos.response.GetAllBookResponseDto;
import com.sic.biblioteca.app.mapper.BookAppMapper;
import com.sic.biblioteca.domain.service.BookServiceDomain;
import com.sic.biblioteca.domain.util.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class BookAppService {
    @Autowired
    private BookServiceDomain bookServiceDomain;
    @Autowired
    private BookAppMapper bookAppMapper;

    public CreateBookResponseDto createBook(CreateBookRequestDto createBookRequestDto) {

        CreateBookResponseDto createBookResponseDto = new CreateBookResponseDto();
        BookDto bookDto = bookAppMapper.bookDomainToBookDto(
                bookServiceDomain.createBook(
                        bookAppMapper.bookDtoToBookDomain(
                                bookAppMapper.createBookRequestDtoToBookDto(
                                        createBookRequestDto))));
        createBookResponseDto.setResponseCode(Util.CODE_SUCCESS);
        createBookResponseDto.setResponseMessage(Util.MESSAGE_SUCCESS);
        createBookResponseDto.setCreated_at(bookDto.getCreated_at());
        createBookResponseDto.setModified_at(bookDto.getModified_at());

        return createBookResponseDto;
    }

    public GetAllBookResponseDto getBookByAuthorName (GetBookByAuthorNameRequestDto getBookByAuthorNameRequestDto){

        GetAllBookResponseDto getAllBookResponseDto = new GetAllBookResponseDto();
        getAllBookResponseDto.setData(
                bookAppMapper.bookDtoListToBookResponseDtoList(
                        bookAppMapper.bookDomainListToBookDtoList(
                                bookServiceDomain.getBookByAuthorName(
                                        getBookByAuthorNameRequestDto.getName()))));
        getAllBookResponseDto.setResponseCode(Util.CODE_SUCCESS);
        getAllBookResponseDto.setResponseMessage(Util.MESSAGE_SUCCESS);
        return getAllBookResponseDto;
    }

    public GetAllBookResponseDto getBookByTitle (GetBookByTitleRequestDto getBookByTitleRequestDto){

        GetAllBookResponseDto getAllBookResponseDto = new GetAllBookResponseDto();
        getAllBookResponseDto.setData(
                bookAppMapper.bookDtoListToBookResponseDtoList(
                        bookAppMapper.bookDomainListToBookDtoList(
                                bookServiceDomain.getBookByTitle(
                                        getBookByTitleRequestDto.getTitle()))));
        getAllBookResponseDto.setResponseCode(Util.CODE_SUCCESS);
        getAllBookResponseDto.setResponseMessage(Util.MESSAGE_SUCCESS);
        return getAllBookResponseDto;
    }




}
