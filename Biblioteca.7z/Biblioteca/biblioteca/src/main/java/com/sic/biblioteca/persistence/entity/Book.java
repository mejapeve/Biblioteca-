package com.sic.biblioteca.persistence.entity;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import java.time.LocalDateTime;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "books")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name="title")
    private String title;
    @Column(name="isbn")
    private String isbn;
    @Column(name="year")
    private int year;
    @CreatedDate
    @Column(name = "created_at", updatable=false)
    private LocalDateTime created_at;
    @LastModifiedDate
    @Column(name = "modified_at")
    private LocalDateTime modified_at;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "author_id", nullable = false)
    private Author author;

}
