package com.sic.biblioteca.app.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value= HttpStatus.BAD_REQUEST)
public class AuthorDoesNotExist extends RuntimeException{
    public AuthorDoesNotExist(String message) {
        super(message);
    }
}
