package com.sic.biblioteca.domain.service;

import com.sic.biblioteca.app.exceptions.AuthorAlreadyExists;
import com.sic.biblioteca.app.exceptions.AuthorDoesNotExist;
import com.sic.biblioteca.domain.entity.AuthorDomain;
import com.sic.biblioteca.domain.entity.BookDomain;
import com.sic.biblioteca.domain.repository.AuthorRepositoryDomain;
import com.sic.biblioteca.domain.repository.BookRepositoryDomain;
import com.sic.biblioteca.persistence.entity.Author;
import com.sic.biblioteca.persistence.entity.Book;
import com.sic.biblioteca.persistence.repositoyJpa.BookRepositoryJpa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BookServiceDomain {
    @Autowired
    private BookRepositoryDomain bookRepositoryDomain;
    @Autowired
    private AuthorRepositoryDomain authorRepositoryDomain;

    public BookDomain createBook(BookDomain bookDomain) {

        Optional<AuthorDomain> authorDomain = authorRepositoryDomain.findAuthorById(bookDomain.getAuthorId());

        if (authorDomain.isPresent()) {
            bookDomain.setCreated_at(LocalDateTime.now());
            bookDomain.setModified_at(LocalDateTime.now());
            bookDomain.setAuthorDomain(authorDomain.get());
            bookRepositoryDomain.createBook(bookDomain);
        } else {
            throw new AuthorDoesNotExist("The Author with ID " + bookDomain.getAuthorId() + " does not exist");
        }
        return bookDomain;
    }

    public List<BookDomain> getBookByAuthorName(String authorName) {

        List<BookDomain> bookDomainList = bookRepositoryDomain.findByAuthorName(authorName);
        if (!bookDomainList.isEmpty()) {
            return bookDomainList;
        } else {
            throw new AuthorDoesNotExist("The author " + authorName + " has no registered books");
        }

    }

    public List<BookDomain> getBookByTitle(String title) {

        List<BookDomain> bookDomainList = bookRepositoryDomain.findByTitle(title);
        if (!bookDomainList.isEmpty()) {
            return bookDomainList;
        } else {
            throw new AuthorDoesNotExist("The author " + title + " has no registered books");
        }

    }


}
