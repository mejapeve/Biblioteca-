package com.sic.biblioteca.persistence.mapper;

import com.sic.biblioteca.domain.entity.BookDomain;
import com.sic.biblioteca.persistence.entity.Book;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface BookMapper {

    @Mapping(source = "authorDomain", target = "author")
    Book bookDomainTobook(BookDomain bookDomain);
    @Mapping(source = "author",target = "authorDomain")
    BookDomain bookToBookDomain(Book book);
    List<BookDomain> bookListToBookDomainList(List<Book> bookList);
}
