package com.sic.biblioteca.app.mapper;


import com.sic.biblioteca.app.dtos.AuthorDto;
import com.sic.biblioteca.app.dtos.request.CreateAuthorRequestDto;
import com.sic.biblioteca.domain.entity.AuthorDomain;
import org.mapstruct.Mapper;



@Mapper(componentModel = "spring")
public interface AuthorAppMapper {

    AuthorDomain authorDtoToAuthorDomain(AuthorDto authorDto);
    AuthorDto authorDomainToAuthorDto(AuthorDomain authorDomain);

    default AuthorDto creteAuthorRequestDtoToAuthorDto (CreateAuthorRequestDto createAuthorRequestDto){

        AuthorDto authorDto = new AuthorDto();
        authorDto.setName(createAuthorRequestDto.getName());
        authorDto.setEmail(createAuthorRequestDto.getEmail());
        return authorDto;

    }
}




