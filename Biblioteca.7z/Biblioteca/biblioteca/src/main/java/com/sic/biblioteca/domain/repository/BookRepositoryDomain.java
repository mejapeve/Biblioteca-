package com.sic.biblioteca.domain.repository;

import com.sic.biblioteca.domain.entity.AuthorDomain;
import com.sic.biblioteca.domain.entity.BookDomain;
import com.sic.biblioteca.persistence.entity.Book;

import java.util.List;
import java.util.Optional;

public interface BookRepositoryDomain {

    Book createBook (BookDomain bookDomain);
    Optional<BookDomain> findBookByIsbn (String isbn);
    List <BookDomain> findByAuthorName (String authorName);
    List <BookDomain> findByTitle (String title);


}
