package com.sic.biblioteca.app.service;

import com.sic.biblioteca.app.dtos.AuthorDto;
import com.sic.biblioteca.app.dtos.request.CreateAuthorRequestDto;
import com.sic.biblioteca.app.dtos.response.CreateAuthorResponseDto;
import com.sic.biblioteca.domain.service.AuthorServiceDomain;
import com.sic.biblioteca.app.mapper.AuthorAppMapper;
import com.sic.biblioteca.domain.util.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthorAppService {

    @Autowired
    private AuthorServiceDomain authorServiceDomain;
    @Autowired
    private AuthorAppMapper authorAppMapper;

    public CreateAuthorResponseDto createAuthor(CreateAuthorRequestDto createAuthorRequestDto) {

        CreateAuthorResponseDto createAuthorResponseDto = new CreateAuthorResponseDto();
        AuthorDto authorDto = authorAppMapper.authorDomainToAuthorDto(
                authorServiceDomain.createAuthor(
                        authorAppMapper.authorDtoToAuthorDomain(
                                authorAppMapper.creteAuthorRequestDtoToAuthorDto(createAuthorRequestDto))));

        createAuthorResponseDto.setResponseCode(Util.CODE_SUCCESS);
        createAuthorResponseDto.setResponseMessage(Util.MESSAGE_SUCCESS);
        createAuthorResponseDto.setCreated_at(authorDto.getCreated_at());
        createAuthorResponseDto.setModified_at(authorDto.getModified_at());

        return createAuthorResponseDto;
    }
}
