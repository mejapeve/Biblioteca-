package com.sic.biblioteca.app.dtos.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetAllBookResponseDto {
    private String ResponseCode;
    private String ResponseMessage;
    private List<BookResponseDto> data;
}
