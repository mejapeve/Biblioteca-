package com.sic.biblioteca.app.dtos.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookResponseDto {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private long id;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String title;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String isbn;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private int year;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private LocalDateTime created_at;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private LocalDateTime modified_at;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String nameAuthor;

}
