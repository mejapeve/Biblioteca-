package com.sic.biblioteca.app.controllers;

import com.sic.biblioteca.app.dtos.response.ContactInfoResponseDto;
import com.sic.biblioteca.app.dtos.response.ErrorResponseDto;
import com.sic.biblioteca.app.dtos.request.CreateAuthorRequestDto;
import com.sic.biblioteca.app.dtos.response.CreateAuthorResponseDto;
import com.sic.biblioteca.app.exceptions.IncorrectPattern;
import com.sic.biblioteca.app.service.AuthorAppService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;



@Tag(
        name = "Controller for Author service",
        description = "Endpoint for service CRUD operations"
)
@Validated
@RestController
@CrossOrigin("*")
@RequestMapping(path = "/Authors", produces = {MediaType.APPLICATION_JSON_VALUE})
public class AuthorController {

    @Autowired
    private AuthorAppService authorAppService;
    @Autowired
    private ContactInfoResponseDto contactInfoResponseDto;

    @Value("${email.regexp}")
    private String emailPattern;

    @Value("${email.message}")
    private String messageEmail;


    @Operation(
            summary = "Create Author",
            description = "Create a author in the system"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "HTTP status create"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP internal server error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )

    })
    @PostMapping("/createAuthor")
    public ResponseEntity<CreateAuthorResponseDto> createAuthor(@Valid @RequestBody CreateAuthorRequestDto createAuthorRequestDto){


        if (!createAuthorRequestDto.getEmail().matches(emailPattern)) {
            throw new IncorrectPattern("email",messageEmail);
        }

        CreateAuthorResponseDto createAuthorResponseDto = authorAppService.createAuthor(createAuthorRequestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createAuthorResponseDto);
    }

    @Operation(
            summary = "Contact Info User",
            description = "View developer contact information"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "HTTP status generate"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP internal server error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )

    })
    @GetMapping("/contact-info")
    public ResponseEntity<ContactInfoResponseDto> getContactInfo() {
        return ResponseEntity.status(HttpStatus.OK).body(contactInfoResponseDto);
    }

}
