package com.sic.biblioteca.domain.entity;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookDomain {
    @NotNull
    private long id;
    @NotNull
    private long authorId;
    @NotNull
    private String title;
    @NotNull
    private String isbn;
    @NotNull
    private int year;
    @NotNull
    private LocalDateTime created_at;
    @NotNull
    private LocalDateTime modified_at;
    @NotNull
    private AuthorDomain authorDomain;


}
