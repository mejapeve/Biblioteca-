package com.sic.biblioteca.app.dtos.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
public class CreateAuthorResponseDto {
    private String ResponseCode;
    private String ResponseMessage;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private LocalDateTime created_at;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private LocalDateTime modified_at;
}
