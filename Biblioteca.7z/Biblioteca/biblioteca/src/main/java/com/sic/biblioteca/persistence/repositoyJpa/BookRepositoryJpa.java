package com.sic.biblioteca.persistence.repositoyJpa;

import com.sic.biblioteca.persistence.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepositoryJpa extends JpaRepository <Book,Long> {
    Optional<Book> findByIsbn (String isbn);
    @Query(value = "SELECT b FROM Book b WHERE UPPER(b.author.name) LIKE UPPER(CONCAT('%', :authorName ,'%'))")
    List<Book> findByAuthorName (@Param(value = "authorName")String authorName);

    @Query(value = "SELECT b FROM Book b WHERE UPPER(b.title) LIKE UPPER(CONCAT('%', :title ,'%'))")
    List<Book> findByTitle (@Param(value = "title")String title);

}
