package com.sic.biblioteca.app.mapper;

import com.sic.biblioteca.app.dtos.BookDto;
import com.sic.biblioteca.app.dtos.request.CreateBookRequestDto;
import com.sic.biblioteca.app.dtos.response.BookResponseDto;
import com.sic.biblioteca.domain.entity.BookDomain;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.ArrayList;
import java.util.List;


@Mapper(componentModel = "spring")
public interface BookAppMapper {
    BookDomain bookDtoToBookDomain(BookDto bookDto);

    @Mapping(target = "authorDto",source = "authorDomain")
    BookDto bookDomainToBookDto(BookDomain bookDomain);

    default  BookDto createBookRequestDtoToBookDto (CreateBookRequestDto createBookRequestDto){

        BookDto bookDto = new BookDto();
        bookDto.setAuthorId(createBookRequestDto.getAuthorId());
        bookDto.setTitle(createBookRequestDto.getTitle());
        bookDto.setIsbn(createBookRequestDto.getIsbn());
        bookDto.setYear(createBookRequestDto.getYear());

        return bookDto;
    }
    @Mapping(target = "authorDto",source = "authorDomain")
    List<BookDto>  bookDomainListToBookDtoList (List<BookDomain> bookDomainList);

    default List<BookResponseDto> bookDtoListToBookResponseDtoList(List<BookDto> bookDtoList) {
        if ( bookDtoList == null ) {
            return null;
        }

        List<BookResponseDto> list = new ArrayList<>( bookDtoList.size() );
        for ( BookDto bookDto : bookDtoList ) {
            list.add( bookDtoToBookResponseDto(bookDto) );
        }
        return list;
    }
    default BookResponseDto bookDtoToBookResponseDto(BookDto bookDto) {
        if ( bookDto == null ) {
            return null;
        }
        BookResponseDto bookResponseDto = new BookResponseDto();

        bookResponseDto.setId( bookDto.getId() );
        bookResponseDto.setTitle( bookDto.getTitle() );
        bookResponseDto.setIsbn( bookDto.getIsbn() );
        bookResponseDto.setYear( bookDto.getYear() );
        bookResponseDto.setCreated_at( bookDto.getCreated_at() );
        bookResponseDto.setModified_at( bookDto.getModified_at() );
        bookResponseDto.setNameAuthor(bookDto.getAuthorDto().getName());

        return bookResponseDto;
    }

}
