package com.sic.biblioteca.app.dtos.request;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
public class CreateBookRequestDto {

    @NotNull(message = "Author ID is required")
    private Long authorId;
    @NotEmpty(message = "The title of the book is required")
    private String title;
    @NotEmpty(message = "The ISBN of the book is required")
    private String isbn;
    @NotNull(message = "The year of publication of the book is required")
    private int year;
}
