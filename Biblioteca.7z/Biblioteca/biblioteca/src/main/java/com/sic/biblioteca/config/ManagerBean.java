package com.sic.biblioteca.config;

import com.sic.biblioteca.domain.repository.AuthorRepositoryDomain;
import com.sic.biblioteca.domain.repository.BookRepositoryDomain;
import com.sic.biblioteca.persistence.repositoyImpl.AuthorRepositoryImpl;
import com.sic.biblioteca.persistence.repositoyImpl.BookRepositoryImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ManagerBean {

    @Bean
    public AuthorRepositoryDomain authorRepositoryDomain() {
        return new AuthorRepositoryImpl();    }

    @Bean
    public BookRepositoryDomain bookRepositoryDomain() {
        return new BookRepositoryImpl();
    }



}
