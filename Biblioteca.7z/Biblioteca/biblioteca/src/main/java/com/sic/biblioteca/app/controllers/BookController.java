package com.sic.biblioteca.app.controllers;

import com.sic.biblioteca.app.dtos.request.CreateBookRequestDto;
import com.sic.biblioteca.app.dtos.request.GetBookByAuthorNameRequestDto;
import com.sic.biblioteca.app.dtos.request.GetBookByTitleRequestDto;
import com.sic.biblioteca.app.dtos.response.ContactInfoResponseDto;
import com.sic.biblioteca.app.dtos.response.CreateBookResponseDto;
import com.sic.biblioteca.app.dtos.response.ErrorResponseDto;
import com.sic.biblioteca.app.dtos.response.GetAllBookResponseDto;
import com.sic.biblioteca.app.service.BookAppService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Tag(
        name = "Controller for Book service",
        description = "Endpoint for service CRUD operations"
)
@Validated
@RestController
@CrossOrigin("*")
@RequestMapping(path = "/books", produces = {MediaType.APPLICATION_JSON_VALUE})
public class BookController {
    @Autowired
    private BookAppService bookAppService;
    @Autowired
    private ContactInfoResponseDto contactInfoResponseDto;

    @Operation(
            summary = "Create Book",
            description = "Create a author in the system"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "HTTP status create"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP internal server error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )


    })
    @PostMapping("/createBook")
    public ResponseEntity<CreateBookResponseDto> createBooks (
            @Valid @RequestBody CreateBookRequestDto createBookRequestDto) {

        CreateBookResponseDto createBookResponseDto = bookAppService.createBook(createBookRequestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createBookResponseDto);
    }
    @Operation(
            summary = "Find Book by Author",
            description = "Book search by author name"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "HTTP status generate"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP internal server error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )

    })
    @GetMapping(value = "byAuthorName/{authorName}")
    public ResponseEntity<GetAllBookResponseDto> getBookByAuthorName(
            @PathVariable(name = "authorName") String authorName) {
        GetAllBookResponseDto getAllBookResponseDto;
        GetBookByAuthorNameRequestDto getBookByAuthorNameRequestDto = new GetBookByAuthorNameRequestDto(authorName);
        getAllBookResponseDto = bookAppService.getBookByAuthorName(getBookByAuthorNameRequestDto);
        return ResponseEntity.status(HttpStatus.OK).body(getAllBookResponseDto);
    }

    @Operation(
            summary = "Find Book by Title",
            description = "Book search by title"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "HTTP status generate"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP internal server error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )

    })
    @GetMapping(value = "byTitle/{title}")
    public ResponseEntity<GetAllBookResponseDto> getBookByTitle(
            @PathVariable(name = "title") String title) {
        GetAllBookResponseDto getAllBookResponseDto;
        GetBookByTitleRequestDto getBookByTitleRequestDto = new GetBookByTitleRequestDto(title);
        getAllBookResponseDto = bookAppService.getBookByTitle(getBookByTitleRequestDto);
        return ResponseEntity.status(HttpStatus.OK).body(getAllBookResponseDto);
    }

    @Operation(
            summary = "Contact Info",
            description = "View developer contact information"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "HTTP status generate"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP internal server error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )

    })
    @GetMapping("/contact-info")
    public ResponseEntity<ContactInfoResponseDto> getContactInfo() {
        return ResponseEntity.status(HttpStatus.OK).body(contactInfoResponseDto);
    }

}
