package com.sic.biblioteca;

import com.sic.biblioteca.app.dtos.response.ContactInfoResponseDto;
import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@OpenAPIDefinition(
		info = @Info(
				title = "Restrictive Bank System",
				description = "User registration API",
				version = "V1",
				contact = @Contact(
						name = "Melquis Jair Peralta Vega",
						email = "mejapeve@gmail.com",
						url = "https://www.devlops.com"
				),
				license = @License(
						name = "Apache 2.0",
						url = "https://www.devlops.com"
				)

		),
		externalDocs = @ExternalDocumentation(
				description = "Project for user registration",
				url = "http://localhost:8070/swagger-ui/index.html"
		)
)
@SpringBootApplication
@EnableConfigurationProperties(value = ContactInfoResponseDto.class)
public class BibliotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaApplication.class, args);
	}

}
