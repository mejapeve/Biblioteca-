package com.sic.biblioteca.domain.util;

public class Util {
    public static final String CODE_SUCCESS = "00";
    public static final String MESSAGE_SUCCESS = "Successful";
}
