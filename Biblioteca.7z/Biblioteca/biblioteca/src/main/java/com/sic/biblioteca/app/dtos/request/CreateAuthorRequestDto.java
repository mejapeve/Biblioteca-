package com.sic.biblioteca.app.dtos.request;

import com.sic.biblioteca.app.dtos.BookDto;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;


@Data
public class CreateAuthorRequestDto {
    @NotEmpty(message = "name is required")
    private String name;
    @NotEmpty(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;
}
