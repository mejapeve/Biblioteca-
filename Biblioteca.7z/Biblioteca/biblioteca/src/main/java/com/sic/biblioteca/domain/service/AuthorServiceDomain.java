package com.sic.biblioteca.domain.service;

import com.sic.biblioteca.domain.entity.AuthorDomain;
import com.sic.biblioteca.app.exceptions.AuthorAlreadyExists;
import com.sic.biblioteca.domain.repository.AuthorRepositoryDomain;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Optional;


@Service
public class AuthorServiceDomain {
    @Autowired
    AuthorRepositoryDomain authorRepositoryDomain;

    public AuthorDomain createAuthor(AuthorDomain authorDomain) {

        Optional<AuthorDomain> AuthorDomain = authorRepositoryDomain.findByEmail(authorDomain.getEmail());

        if (!AuthorDomain.isPresent()) {
            authorDomain.setCreated_at(LocalDateTime.now());
            authorDomain.setModified_at(LocalDateTime.now());

            authorRepositoryDomain.creteAuthor(authorDomain);

        } else {
            throw new AuthorAlreadyExists("The author with the email " + authorDomain.getEmail() + " already exists");
        }
        return authorDomain;
    }

}
