package com.sic.biblioteca.domain.repository;
import com.sic.biblioteca.domain.entity.AuthorDomain;
import com.sic.biblioteca.persistence.entity.Author;


import java.util.List;
import java.util.Optional;

public interface AuthorRepositoryDomain {
    Author creteAuthor (AuthorDomain authorDomain);
    Optional<AuthorDomain> findByEmail (String email);
    Optional<AuthorDomain> findAuthorById (long id);
    List<AuthorDomain> findByName (String name);










}
