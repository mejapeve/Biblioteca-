package com.sic.biblioteca.app.dtos;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthorDto {
    @NotNull
    private long id;
    @NotNull
    private String name;
    @NotNull
    private String email;
    @NotNull
    private LocalDateTime created_at;
    @NotNull
    private LocalDateTime modified_at;
}
