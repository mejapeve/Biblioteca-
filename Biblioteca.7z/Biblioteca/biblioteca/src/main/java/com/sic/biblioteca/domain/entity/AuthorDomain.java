package com.sic.biblioteca.domain.entity;


import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;



@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthorDomain {
    @NotNull
    private long id;
    @NotNull
    private String name;
    @NotNull
    private String email;
    @NotNull
    private LocalDateTime created_at;
    @NotNull
    private LocalDateTime modified_at;
}
