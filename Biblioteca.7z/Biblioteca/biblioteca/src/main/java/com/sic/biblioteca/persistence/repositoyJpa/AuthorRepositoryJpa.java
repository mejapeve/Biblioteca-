package com.sic.biblioteca.persistence.repositoyJpa;

import com.sic.biblioteca.domain.entity.AuthorDomain;
import com.sic.biblioteca.persistence.entity.Author;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AuthorRepositoryJpa extends JpaRepository <Author, Long> {
    Optional<Author> findByEmail(String email);

    @Query(value = "SELECT a FROM Author a WHERE  UPPER(a.name) LIKE UPPER(CONCAT('%', :authorName ,'%')) ")
    List <Author> findByName(@Param("authorName") String authorName);

}

